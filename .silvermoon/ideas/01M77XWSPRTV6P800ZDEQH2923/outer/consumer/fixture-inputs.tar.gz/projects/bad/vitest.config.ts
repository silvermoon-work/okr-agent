
import { defineConfig } from "vitest/config";
export default defineConfig({ test: {
 include: ["test/**/*.test.ts"],
 coverage: { provider: "v8", include: ["src/**/*.ts"], thresholds: { branches: 90, functions: 90, lines: 90, statements: 90 } }
} });